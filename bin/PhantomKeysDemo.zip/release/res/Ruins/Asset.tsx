<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.6.0" name="Asset" tilewidth="32" tileheight="32" tilecount="400" columns="20">
 <image source="Ruin Assets.png" width="640" height="640"/>
</tileset>
