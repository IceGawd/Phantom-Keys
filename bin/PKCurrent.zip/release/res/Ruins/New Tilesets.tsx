<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.6.0" name="New Tilesets" tilewidth="32" tileheight="32" tilecount="420" columns="18">
 <image source="New Tilesets.png" width="576" height="352"/>
 <wangsets>
  <wangset name="Path" type="corner" tile="-1">
   <wangcolor name="" color="#ff0000" tile="-1" probability="1"/>
  </wangset>
  <wangset name="Bricks" type="corner" tile="-1">
   <wangcolor name="" color="#ff0000" tile="-1" probability="1"/>
   <wangtile tileid="121" wangid="0,0,0,1,0,0,0,0"/>
   <wangtile tileid="122" wangid="0,0,0,1,0,1,0,0"/>
   <wangtile tileid="123" wangid="0,0,0,0,0,1,0,0"/>
   <wangtile tileid="135" wangid="0,1,0,1,0,0,0,0"/>
   <wangtile tileid="136" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="137" wangid="0,0,0,0,0,1,0,1"/>
   <wangtile tileid="149" wangid="0,1,0,0,0,0,0,0"/>
   <wangtile tileid="150" wangid="0,1,0,0,0,0,0,1"/>
   <wangtile tileid="151" wangid="0,0,0,0,0,0,0,1"/>
  </wangset>
 </wangsets>
</tileset>
